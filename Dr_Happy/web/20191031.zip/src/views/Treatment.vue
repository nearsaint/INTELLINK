<template>
<div class="treatment boxView">
  <el-page-header @back="goBack" content="疗程编号: A45237465 | 名字: 夏宁梦">
  </el-page-header>
  <questionnaire class="questionnaire"></questionnaire>
  <info class="info"></info>
</div>
</template>

<script>
import info from 'components/treat/info.vue'
import questionnaire from 'components/treat/questionnaire.vue'
export default {
  data() {
    return {}
  },
  beforeCreate: function() {},
  created: function() {},
  mounted: function() {},
  beforeDestroy: function() {},
  destroyed: function() {},
  methods: {
    goBack: function() {
      this.$router.go(-1);
    },
  },
  computed: {},
  watch: {},
  components: {
    questionnaire,
    info
  },
}
</script>
<style lang="scss" scoped>
.treatment {
    padding-bottom: 0;
    > .el-page-header {
        width: 100%;
        margin-bottom: 20px;
    }

    > .info {
        width: calc(30% - 20px);
        // height: calc(100vh - 150px);
        margin-bottom: 20px;
        border: 1px solid #ddd;
        border-radius: 6px;
    }
    > .questionnaire {
        width: 70%;
        min-height: calc(100vh - 150px);
        margin-right: 20px;
        border: 1px solid #ddd;
        border-radius: 6px;
    }
}
</style>
