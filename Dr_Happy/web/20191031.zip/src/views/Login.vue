<template>
<div class="login">
</div>
</template>

<script>
export default {
  data() {
    return {}
  },
  beforeCreate: function() {},
  created: function() {},
  mounted: function() {},
  beforeDestroy: function() {},
  destroyed: function() {},
  methods: {

  },
  computed: {},
  watch: {},
  components: {},
}
</script>
