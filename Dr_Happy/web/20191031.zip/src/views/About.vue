<template>
<div class="about">
  about
</div>
</template>

<script>
export default {
  data() {
    return {
      test: 'this'
    }
  },
  beforeCreate: function() {},
  created: function() {},
  mounted: function() {},
  beforeDestroy: function() {},
  destroyed: function() {},
  methods: {

  },
  computed: {},
  watch: {},
  components: {},
}
</script>
