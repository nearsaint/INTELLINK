<template>
<div class="questionnaire box">
  <div class="title">问卷信息
    <div class="btnContainer">
      <a class="refresh"></a>
    </div>
  </div>
  <div class="content">
    <div class="info">
      <ul>
        <li>
          <h5>进行中</h5>
          <h6>状态</h6>
        </li>
        <li>
          <h5>41</h5>
          <h6>当前天数</h6>
        </li>
        <li>
          <h5>60</h5>
          <h6>周期</h6>
        </li>
        <li>
          <h5>2019-08-30</h5>
          <h6>开始时间</h6>
        </li>
      </ul>
    </div>

    <div class="main">
      <el-collapse v-model="activeName" accordion>
        <el-timeline>
          <el-timeline-item timestamp="医生信息" placement="top" color="#409EFF" icon="el-icon-s-custom" size="large">
            <el-collapse-item title="补全患者治疗" name="1">
              <div>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念；</div>
              <div>在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</div>
            </el-collapse-item>
          </el-timeline-item>
          <el-timeline-item timestamp="Day 1" placement="top" color="#0bbd87">
            <el-collapse-item title="12题" name="1">
              <div>与现实生活一致：与现实生活的流程、逻辑保持一致，遵循用户习惯的语言和概念；</div>
              <div>在界面中一致：所有的元素和结构需保持一致，比如：设计样式、图标和文本、元素的位置等。</div>
            </el-collapse-item>
          </el-timeline-item>
          <el-timeline-item timestamp="Day 2" placement="top" color="#0bbd87">
            <el-collapse-item title="3题" name="2">
              <ul>
                <li>
                  <h5>今天你使用器械治疗了吗?</h5>
                  <h6>是</h6>
                </li>
                <li>
                  <h5>今天器械使用达到40分钟吗？</h5>
                  <h6>是</h6>
                </li>
                <li>
                  <h5>今天症状改善情况？</h5>
                  <h6>少许改善</h6>
                </li>
              </ul>
            </el-collapse-item>
          </el-timeline-item>
          <el-timeline-item timestamp="Day 3" placement="top" color="#F56C6C">
            <h5 class="null">未填写</h5>
          </el-timeline-item>
          <el-timeline-item timestamp="Day 4" placement="top" color="#0bbd87">
            <el-collapse-item title="3题" name="3">
              <ul>
                <li>
                  <h5>今天你使用器械治疗了吗?</h5>
                  <h6>是</h6>
                </li>
                <li>
                  <h5>今天器械使用达到40分钟吗？</h5>
                  <h6>是</h6>
                </li>
                <li>
                  <h5>今天症状改善情况？</h5>
                  <h6>少许改善</h6>
                </li>
              </ul>
            </el-collapse-item>
          </el-timeline-item>
          <el-timeline-item timestamp="Day 4" placement="top" color="#0bbd87">
            <el-collapse-item title="3题" name="4">
              <ul>
                <li>
                  <h5>今天你使用器械治疗了吗?</h5>
                  <h6>是</h6>
                </li>
                <li>
                  <h5>今天器械使用达到40分钟吗？</h5>
                  <h6>是</h6>
                </li>
                <li>
                  <h5>今天症状改善情况？</h5>
                  <h6>少许改善</h6>
                </li>
              </ul>
            </el-collapse-item>
          </el-timeline-item>
          <el-timeline-item timestamp="end" placement="top" color="#909399">
          </el-timeline-item>

        </el-timeline>
      </el-collapse>

    </div>

  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      activeName: 1,
    }
  },
  beforeCreate: function() {},
  created: function() {},
  mounted: function() {},
  beforeDestroy: function() {},
  destroyed: function() {},
  methods: {},
  computed: {},
  watch: {},
  components: {},
}
</script>

<style lang="scss" scoped>
.questionnaire {
    > .content {
        > .info {
            > ul {
                border-top: 1px solid #ddd;
                border-bottom: 1px solid #ddd;
                display: flex;
                flex-wrap: nowrap;
                > li {
                    border-right: 1px solid #ddd;
                    flex-shrink: 0;
                    flex-grow: 1;
                    padding: 15px 10px;
                    text-align: center;
                    &:last-child {
                        border-right: none;
                    }
                    > h5 {
                        font-size: 16px;
                        color: #444;
                        margin-bottom: 6px;
                    }
                    > h6 {
                        font-size: 12px;
                        color: #999;
                    }
                }
            }
        }

        .main {
            padding: 20px;
            .el-collapse {
                border: none;
            }
            .el-timeline-item {

                h5.null {
                    line-height: 48px;
                    font-size: 13px;
                    font-weight: 500;
                    color: #ccc;
                }
                .el-collapse-item {
                    ul {
                        border-radius: 6px;
                        border: 1px solid #ddd;
                        > li {
                            padding: 20px;
                            border-bottom: 1px solid #ddd;
                            &:last-child {
                                border-bottom: none;
                            }
                            > h5 {
                                font-size: 14px;
                                margin-bottom: 8px;
                                color: #666;
                            }
                            > h6 {
                                font-size: 15px;
                                color: #333;
                                font-weight: bold;
                            }
                        }
                    }
                }
            }
        }
    }
}
</style>
<style lang="scss">
.questionnaire {
    .main {
        .el-collapse {
            .el-timeline-item {
                .el-timeline-item__tail {
                    transition: border-color 0.3s;
                }
                &:hover {
                    .el-timeline-item__tail {
                        border-color: #666;
                    }
                }
            }
        }
    }
}
</style>
