const apis = {
  url: 'http://47.104.179.47:5002',
  socket: {
    link: '/data_refresh',
    event: {

    },
  },
  axios: {
    link: '/api',
    event: {
      //176629183
      getLatestRTTags: 'api/Machine/GetLatestRTTags'
    },
  },
  upload: {

  },
}
export default apis